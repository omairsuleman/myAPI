package com.autodrive.model;

public final class Constants {

  public static final String SPACE = " ";

  private Constants() {
  }
}
