# Main classes to test the simulation

SimulationApplication.java
MultipleCarsApplication.java