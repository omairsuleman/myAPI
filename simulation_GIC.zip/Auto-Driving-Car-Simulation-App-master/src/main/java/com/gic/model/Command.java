package com.gic.model;

public enum Command {
    L, R, F;
}
